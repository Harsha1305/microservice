package com.mindtree.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.entity.CampusMind;
import com.mindtree.exception.ApplicationException;
import com.mindtree.service.CampusMindService;

@RestController
public class CampusMindController {
	
	@Autowired
	CampusMindService campusMindService;
	
	@PostMapping("/mind")
	public ResponseEntity< CampusMind>  insertMind(@RequestBody CampusMind campusMind )
	{
		
		 campusMind= campusMindService.insertMinds(campusMind);
		return new ResponseEntity<CampusMind>(campusMind, HttpStatus.CREATED);
	}
	
	@GetMapping("/mind/{mid}")
	public ResponseEntity< CampusMind>  getMind(@PathVariable String mid) throws ApplicationException
	{
		
		CampusMind campusMind= campusMindService.getById(mid);
		return new ResponseEntity<CampusMind>(campusMind, HttpStatus.CREATED);
	}

}
