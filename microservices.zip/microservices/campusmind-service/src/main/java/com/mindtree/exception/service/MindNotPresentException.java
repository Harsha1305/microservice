package com.mindtree.exception.service;

import com.mindtree.exception.ServiceException;

public class MindNotPresentException extends ServiceException {

	public MindNotPresentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MindNotPresentException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public MindNotPresentException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MindNotPresentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MindNotPresentException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
