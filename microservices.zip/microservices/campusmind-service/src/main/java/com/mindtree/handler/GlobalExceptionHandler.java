package com.mindtree.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.mindtree.exception.ApplicationException;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	
	@ExceptionHandler(value= {ApplicationException.class})
	protected ResponseEntity<?> handleConflict(ApplicationException e){
		
		
		
		return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
		
		
	}

}
