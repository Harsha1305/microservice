package com.mindtree.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.entity.CampusMind;
import com.mindtree.exception.ServiceException;
import com.mindtree.exception.service.MindNotPresentException;
import com.mindtree.repository.CampusMindRepository;
import com.mindtree.service.CampusMindService;


@Service
public class CampusMindServiceImpl implements CampusMindService {
	
	@Autowired
	CampusMindRepository campusMindRepo;

	@Override
	public CampusMind insertMinds(CampusMind campusMind) {
		
		return campusMindRepo.save(campusMind);
	}

	@Override
	public CampusMind getById(String mid) throws ServiceException {
		// TODO Auto-generated method stub
		Optional<CampusMind> campusMind=campusMindRepo.findById(mid);
		if(!campusMind.isPresent())
		{
			throw new MindNotPresentException("Mind not Present");
		}
		return campusMind.get();
	}

}
