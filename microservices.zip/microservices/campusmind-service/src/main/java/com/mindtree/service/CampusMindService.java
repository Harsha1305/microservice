package com.mindtree.service;

import com.mindtree.entity.CampusMind;
import com.mindtree.exception.ServiceException;

public interface CampusMindService {

	CampusMind insertMinds(CampusMind campusMind);

	CampusMind getById(String mid) throws ServiceException;

}
