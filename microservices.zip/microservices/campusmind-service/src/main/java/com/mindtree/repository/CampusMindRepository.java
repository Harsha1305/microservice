package com.mindtree.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.entity.CampusMind;

public interface CampusMindRepository extends JpaRepository<CampusMind,String> {

}
