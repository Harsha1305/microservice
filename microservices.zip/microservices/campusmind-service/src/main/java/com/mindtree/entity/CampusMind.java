package com.mindtree.entity;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class CampusMind {
	
	@Id
	private String mid;
	private String name;
	private String projectName;
	
	public CampusMind() {
		super();
	}


	public CampusMind(String mid, String name, String projectName) {
		super();
		this.mid = mid;
		this.name = name;
		this.projectName = projectName;
	}


	public String getMid() {
		return mid;
	}


	public void setMid(String mid) {
		this.mid = mid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getProjectName() {
		return projectName;
	}


	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}



}
