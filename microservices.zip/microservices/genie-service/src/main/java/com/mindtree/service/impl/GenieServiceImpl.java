package com.mindtree.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dto.CampusMindDto;
import com.mindtree.entity.Genie;
import com.mindtree.exception.CampusMindApplicationException;
import com.mindtree.exception.ServiceException;
import com.mindtree.proxy.CampusMindProxy;
import com.mindtree.repository.GenieRepository;
import com.mindtree.service.GenieService;

import feign.FeignException;


@Service
public class GenieServiceImpl implements GenieService {
	
	@Autowired
	GenieRepository genieRepo;
	
	@Autowired
	CampusMindProxy proxy;

	@Override
	public Genie raiseGenie(String mid, Genie genie) throws ServiceException  {
	    try {
			CampusMindDto campusmind =proxy.getMind(mid).getBody();
			genie.setMid(campusmind.getMid());
		} catch (FeignException e) {
			throw new ServiceException(e.contentUTF8());
			
		}
		return genieRepo.save(genie);
	}

	@Override
	public List<Genie> getGenieByMid(String mid) throws ServiceException {
		CampusMindDto campusmind=null;
		  try {
				 campusmind =proxy.getMind(mid).getBody();
			} catch (FeignException e) {
				throw new ServiceException(e.contentUTF8());
				
			}
		  
		  List<Genie> list=genieRepo.findAll();
		  
		return list.stream().filter(g->g.getMid().compareTo(mid)==0).collect(Collectors.toList());
	}

}
