package com.mindtree.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.mindtree.dto.CampusMindDto;
import com.mindtree.exception.CampusMindApplicationException;

@FeignClient(name="campusmind-service")
public interface CampusMindProxy {
	
	
	@GetMapping("/mind/{mid}")
	public ResponseEntity< CampusMindDto>  getMind(@PathVariable String mid) throws CampusMindApplicationException;

}
