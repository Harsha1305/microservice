package com.mindtree.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Genie {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int genieId;
	private String genieDesription;
	private boolean genieStatus;
	
	private String mid;

	public Genie() {
		super();
	}


	public Genie(int genieId, String genieDesription, boolean genieStatus, String mid) {
		super();
		this.genieId = genieId;
		this.genieDesription = genieDesription;
		this.genieStatus = genieStatus;
		this.mid = mid;
	}


	public int getGenieId() {
		return genieId;
	}

	public void setGenieId(int genieId) {
		this.genieId = genieId;
	}

	public String getGenieDesription() {
		return genieDesription;
	}

	public void setGenieDesription(String genieDesription) {
		this.genieDesription = genieDesription;
	}

	public boolean isGenieStatus() {
		return genieStatus;
	}

	public void setGenieStatus(boolean genieStatus) {
		this.genieStatus = genieStatus;
	}


	public String getMid() {
		return mid;
	}


	public void setMid(String mid) {
		this.mid = mid;
	}
	
	



}
