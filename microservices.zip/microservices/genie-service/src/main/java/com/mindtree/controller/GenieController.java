package com.mindtree.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.entity.Genie;
import com.mindtree.exception.ApplicationException;
import com.mindtree.service.GenieService;

@RestController
public class GenieController {

	@Autowired
	GenieService genieService;

	@PostMapping("/raiseGenie/{mid}")
	public ResponseEntity<Genie> raiseGenieToMind(@PathVariable String mid, @RequestBody Genie genie)
			throws ApplicationException {

		// CampusMind campusmind = campusmindservice.checkId(mid);
		genie = genieService.raiseGenie(mid, genie);
		return new ResponseEntity<Genie>(genie, HttpStatus.CREATED);

	}
	
	@GetMapping("/raiseGenie/{mid}")
	public ResponseEntity<List<Genie>> getAllGenie(@PathVariable String mid)
			throws ApplicationException {
		
		List<Genie> list = new ArrayList<Genie>();
		list = genieService.getGenieByMid(mid);
		return new ResponseEntity<List<Genie>>(list, HttpStatus.FOUND);

	}

}
