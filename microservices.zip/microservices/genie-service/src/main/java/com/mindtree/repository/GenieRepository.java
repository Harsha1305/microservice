package com.mindtree.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.entity.Genie;

public interface GenieRepository extends JpaRepository<Genie, Integer> {

}
