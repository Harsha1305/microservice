package com.mindtree.service;

import java.util.List;

import com.mindtree.entity.Genie;
import com.mindtree.exception.ServiceException;

public interface GenieService {

	Genie raiseGenie(String mid, Genie genie) throws ServiceException;

	List<Genie> getGenieByMid(String mid) throws ServiceException;

}
